import{j as s,L as e}from"./index-9f91b684.js";const t=()=>s.jsxs("div",{children:["This page doesn't exist. Go ",s.jsx(e,{to:"/",children:"home"})]});export{t as default};
