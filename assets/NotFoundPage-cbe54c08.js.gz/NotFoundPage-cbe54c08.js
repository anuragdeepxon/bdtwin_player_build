import{j as s,L as e}from"./index-de1f1ee0.js";const t=()=>s.jsxs("div",{children:["This page doesn't exist. Go ",s.jsx(e,{to:"/",children:"home"})]});export{t as default};
