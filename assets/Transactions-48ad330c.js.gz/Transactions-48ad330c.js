import{s as t,r as a,_ as o,j as s}from"./index-e2f6fba7.js";import{T as i}from"./Title-8617274d.js";const n=t.section`
  padding: 0 15px;
`,e=t.div`
  max-width: 1124px;
  width: 100%;
  padding: 24px 30px 106px 30px;
  margin: 0 auto;
  position: relative;
  margin-top: 60px;
  margin-bottom: 60px;
  background-color: #151515;
  border-radius: 8px;
`,p=a.lazy(()=>o(()=>import("./TransactionsTable-6ee38eef.js"),["assets/TransactionsTable-6ee38eef.js","assets/index-e2f6fba7.js","assets/Pagination.styles-2918fba9.js","assets/Pagination-297004ea.js"])),x=r=>s.jsx(a.Suspense,{fallback:null,children:s.jsx(p,{...r})}),c=()=>s.jsx(n,{children:s.jsxs(e,{children:[s.jsx(i,{title:"TRANSACTIONS"}),s.jsx(x,{})]})});export{c as default};
