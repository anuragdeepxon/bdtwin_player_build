import{j as s,L as e}from"./index-3795215b.js";const t=()=>s.jsxs("div",{children:["This page doesn't exist. Go ",s.jsx(e,{to:"/",children:"home"})]});export{t as default};
