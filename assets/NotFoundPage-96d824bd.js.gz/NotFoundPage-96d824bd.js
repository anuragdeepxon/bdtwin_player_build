import{j as s,L as e}from"./index-f6a63d74.js";const t=()=>s.jsxs("div",{children:["This page doesn't exist. Go ",s.jsx(e,{to:"/",children:"home"})]});export{t as default};
