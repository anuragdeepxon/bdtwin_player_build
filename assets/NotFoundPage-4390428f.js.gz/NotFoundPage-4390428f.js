import{j as s,L as e}from"./index-e9006a23.js";const t=()=>s.jsxs("div",{children:["This page doesn't exist. Go ",s.jsx(e,{to:"/",children:"home"})]});export{t as default};
