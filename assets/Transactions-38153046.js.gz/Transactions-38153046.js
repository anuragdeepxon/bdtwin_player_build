import{s as a,r as t,_ as n,j as s,T as o}from"./index-feb8638f.js";const i=a.section`
  padding: 0 15px;
`,e=a.div`
  max-width: 1124px;
  width: 100%;
  padding: 24px 30px 106px 30px;
  margin: 0 auto;
  position: relative;
  margin-top: 60px;
  margin-bottom: 60px;
  background-color: #151515;
  border-radius: 8px;
`,p=t.lazy(()=>n(()=>import("./TransactionsTable-dda71b19.js"),["assets/TransactionsTable-dda71b19.js","assets/index-feb8638f.js"])),x=r=>s.jsx(t.Suspense,{fallback:null,children:s.jsx(p,{...r})}),l=()=>s.jsx(i,{children:s.jsxs(e,{children:[s.jsx(o,{title:"TRANSACTIONS"}),s.jsx(x,{})]})});export{l as default};
