import{s as t,r as a,_ as o,j as s}from"./index-3795215b.js";import{T as i}from"./Title-4473566c.js";const n=t.section`
  padding: 0 15px;
`,e=t.div`
  max-width: 1124px;
  width: 100%;
  padding: 24px 30px 106px 30px;
  margin: 0 auto;
  position: relative;
  margin-top: 60px;
  margin-bottom: 60px;
  background-color: #151515;
  border-radius: 8px;
`,p=a.lazy(()=>o(()=>import("./TransactionsTable-33e86d42.js"),["assets/TransactionsTable-33e86d42.js","assets/index-3795215b.js","assets/index-800906c4.css","assets/Pagination-e6940298.js","assets/Pagination.styles-f1c1d22f.js"])),x=r=>s.jsx(a.Suspense,{fallback:null,children:s.jsx(p,{...r})}),c=()=>s.jsx(n,{children:s.jsxs(e,{children:[s.jsx(i,{title:"TRANSACTIONS"}),s.jsx(x,{})]})});export{c as default};
