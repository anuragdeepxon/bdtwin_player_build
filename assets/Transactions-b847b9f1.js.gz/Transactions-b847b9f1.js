import{s as t,r as a,_ as o,j as s}from"./index-ed709c53.js";import{T as i}from"./Title-e8f8c320.js";const n=t.section`
  padding: 0 15px;
`,e=t.div`
  max-width: 1124px;
  width: 100%;
  padding: 24px 30px 106px 30px;
  margin: 0 auto;
  position: relative;
  margin-top: 60px;
  margin-bottom: 60px;
  background-color: #151515;
  border-radius: 8px;
`,p=a.lazy(()=>o(()=>import("./TransactionsTable-39716159.js"),["assets/TransactionsTable-39716159.js","assets/index-ed709c53.js","assets/index-55fec1ff.css","assets/Pagination-789f24d9.js","assets/Pagination.styles-7ed6105c.js"])),x=r=>s.jsx(a.Suspense,{fallback:null,children:s.jsx(p,{...r})}),c=()=>s.jsx(n,{children:s.jsxs(e,{children:[s.jsx(i,{title:"TRANSACTIONS"}),s.jsx(x,{})]})});export{c as default};
